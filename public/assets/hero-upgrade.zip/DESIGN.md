# Tactical Intelligence Design System

## 1. Overview & Creative North Star: "The Tactical Command Center"

This design system is engineered for the elite strategist. It departs from the friendly, rounded aesthetic of consumer web apps, leaning instead into a high-performance, mission-critical interface. 

**Creative North Star: The Kinetic HUD**
The experience should feel like a high-end Heads-Up Display (HUD) found in advanced aerospace or tactical simulation hardware. We achieve this through "Kinetic Depth"—where the UI isn't a flat page, but a series of reactive, semi-transparent layers. We break the standard box-grid layout by using intentional asymmetry, data-dense typography, and "ghost" containers that suggest structure without the clutter of traditional borders. This is a system built for speed, precision, and technical authority.

---

## 2. Colors & Surface Logic

Our palette is rooted in obsidian depths and energized by high-visibility tactical accents.

### The "No-Line" Rule
Traditional 1px solid borders are strictly prohibited for defining sections. Structure is achieved through:
- **Tonal Shifts:** Moving between `surface_container_lowest` and `surface_container_high`.
- **Negative Space:** Using a strict spacing scale to separate modules.
- **Glass Refraction:** Using backdrop blurs on `secondary_container` (at low opacity) to suggest a physical pane of glass.

### Surface Hierarchy & Nesting
Treat the screen as a stack of obsidian plates.
*   **Base Layer:** `surface` (#0c1324) – The void.
*   **Module Backgrounds:** `surface_container_low` – Used for primary content areas.
*   **Nested Elements:** `surface_container_highest` – Use this for active cards or interactive sub-panels within a module.

### The Glass & Gradient Rule
To achieve the "Elite" brand personality, utilize the **Tactical Glow**:
- **CTAs:** Use a linear gradient from `primary` (#ffc082) to `primary_container` (#ff9900) at a 135-degree angle.
- **Data Overlays:** Floating HUD elements should use a semi-transparent `surface_bright` with a `backdrop-filter: blur(12px)`. This creates the signature frosted glass effect visible in high-tech command interfaces.

---

## 3. Typography: Technical Precision

Our type system balances the brutalist geometry of Space Grotesk with the humanistic readability of Manrope.

*   **Display & Headlines (Space Grotesk):** Used for high-impact data points and section titles. The wide apertures and geometric construction convey a "technical" and "future-forward" vibe. Use `display-lg` for mission titles to command immediate attention.
*   **Navigation & Body (Manrope):** The primary workhorse. Manrope provides the necessary legibility for dense strategy guides and roster lists.
*   **Technical Labels (Inter):** Reserved for metadata, coordinates, and system status. Inter’s neutral, "no-nonsense" character works perfectly for the `label-sm` and `label-md` tokens, especially when set in uppercase with 0.05em letter spacing.

---

## 4. Elevation & Depth

We eschew "material" shadows in favor of **Tonal Layering** and **Luminescent Depth**.

*   **The Layering Principle:** Instead of shadows, elevate a card by placing a `surface_container_high` object onto a `surface_dim` background. The contrast in value provides a cleaner, more modern lift.
*   **Ambient Shadows:** For floating modals, use a vastly diffused shadow: `box-shadow: 0 20px 50px rgba(0, 241, 254, 0.08)`. Note the use of a tinted shadow (using the secondary blue) to simulate the glow of a screen.
*   **The "Ghost Border":** When containment is mandatory (e.g., input fields), use `outline_variant` at 15% opacity. It should look like a faint light-leak on the edge of a glass pane, not a drawn line.
*   **Grid Textures:** Use a subtle 24px grid pattern overlay at 3% opacity on the `surface` layer to reinforce the "Tactical Workspace" feel.

---

## 5. Components

### Buttons
*   **Primary:** Gradient of `primary` to `primary_container`. Sharp corners (0.25rem). Add a 2px "outer glow" of `primary` on hover.
*   **Secondary:** Ghost style. `outline` at 20% opacity. Text in `secondary`.
*   **Tactical Action:** Small, square-ish buttons using `secondary_container` with a neon-blue (`secondary`) icon.

### Cards & Lists
*   **Constraint:** No dividers. Use a 1px gap with the background color showing through, or a shift from `surface_container_low` to `surface_container_lowest`.
*   **Active State:** Use a "faint glow" border—a 1px inner stroke using `secondary` at 40% opacity.

### Input Fields
*   **Base:** `surface_container_lowest`.
*   **Focus:** A sharp transition to a 1px `primary` border with a subtle 4px blur "outer glow."
*   **Technical Readout:** Always include a small `label-sm` technical descriptor (e.g., [USR_INPUT_FIELD]) in the top-right corner to maintain the HUD aesthetic.

### Data Chips
*   **Selection:** Use `secondary_fixed_dim` for the background with `on_secondary_fixed` text.
*   **Style:** Sharp edges (0px or 2px max). Avoid "pill" shapes; they are too soft for a tactical system.

---

## 6. Do’s and Don’ts

### Do
*   **Use Asymmetry:** Place data readouts off-center to create a bespoke, editorial feel.
*   **Embrace High Contrast:** Let the vibrant `primary` amber pop against the `surface_dim` backgrounds.
*   **Monospace for Numbers:** Use Inter or a monospace alternative for all numerical data and coordinates to ensure alignment and a "coded" feel.

### Don’t
*   **No Rounded Corners:** Avoid the `xl` or `full` roundedness tokens for structural elements. Stick to `none`, `sm`, or `md` to keep the interface feeling "sharp" and "precise."
*   **No Heavy Borders:** Never use a 100% opaque border. It breaks the "glass" immersion.
*   **No Standard Greys:** Avoid neutral greys (#808080). Use our tinted `on_surface_variant` (#dbc2ad) to maintain the warm, high-tech obsidian atmosphere.
*   **No Crowding:** This system requires "Breathing Room." High-density data must be balanced by significant negative space around the modules.