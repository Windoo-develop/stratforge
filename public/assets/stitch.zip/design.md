# Tactical Intelligence Design System: Obsidian Vanguard

## 1. Overview & Creative North Star: "The Tactical Command Center"
This design system is engineered for the elite strategist. It departs from the friendly, rounded aesthetic of consumer apps to embrace a high-fidelity, military-grade interface. The core philosophy is **Functional Brutalism**—every pixel must serve a purpose, and every interaction must feel like a tactical execution.

## 2. Visual Foundation

### Color Palette
*   **Primary Surface (Obsidian):** `#020617` (Slate 950) - The deep, light-absorbing base for high-contrast visibility.
*   **Tactical Accent (Amber/Orange):** `#FF9900` - Used for critical CTAs, status indicators, and primary branding.
*   **Secondary Data (Slate):** `#475569` (Slate 500) - For non-essential metadata and background borders.
*   **Status Indicators:**
    *   *Active:* `#22C55E` (Green 500)
    *   *Alert:* `#EF4444` (Red 500)

### Typography
*   **Headlines:** *Space Grotesk* - A geometric sans-serif that evokes a technical, aerospace aesthetic.
*   **Body & Metadata:** *Inter* - High-readability sans-serif for dense tactical information.
*   **Styling:** Heavy use of uppercase, wide letter-spacing (`tracking-widest`), and monospaced digits for a "terminal" feel.

### Geometry & Texture
*   **Roundness:** Minimal (`4px` - `ROUND_FOUR`). Sharp corners dominate to maintain a technical edge.
*   **Borders:** Fine, low-opacity borders (`border-orange-500/10`) to define sections without adding visual weight.
*   **Gradients:** Subtle radial gradients to create "depth" without traditional shadows.

## 3. Core Components

### Top Navigation Bar
*   **Brand Logo:** Uppercase, tracking-tighter, high-contrast amber.
*   **Interactions:** Hover states use subtle amber underlines and scale transitions.
*   **Background:** High-opacity backdrop blur (`backdrop-blur-xl`) over Slate 950.

### Tactical Feature Cards
*   **Structure:** Monospaced ID tags (e.g., `[ CAP_01 ]`), bold headlines, and integrated data visualizations.
*   **Visuals:** Integrated wireframe or blueprint-style graphics to reinforce the "planning" nature of the tool.

### Map Archive Cards
*   **Imagery:** Grayscale or low-saturation previews with high-contrast tactical overlays.
*   **Metadata:** Compact tags for `Tactics` and `Difficulty` levels.

### Footer (System Status)
*   **Version Tracking:** Explicit version numbers (e.g., `[VER_2.4.0]`) to emphasize the "living system" aspect.
*   **Layout:** Wide spacing with uppercase links and system-ready icons.

## 4. Interaction Principles
1.  **High Latency Simulation:** UI elements should respond with sharp, instantaneous transitions.
2.  **Information Density:** Don't fear the void; whitespace is used strategically to separate logical clusters of complex data.
3.  **Visual Hierarchy:** Use color (Amber) sparingly but aggressively to guide the eye to the primary mission objective (CTAs).